import SwiftUI
import SwiftData
import Charts
import UIKit

@MainActor
struct WorkoutSessionScreen: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var goalPrefill: GoalPrefillStore
    @Environment(\.modelContext) private var modelContext


    @Bindable var session: WorkoutSession

    @StateObject private var logging = WorkoutLoggingService()
    @StateObject private var prefs = UserPreferences.shared
    @State private var restTimerRunID = UUID()

    /// Display numbering for set rows.
    ///
    /// Historically some builders stored `WorkoutSetLog.order` as 0-based (0,1,2,...) while
    /// others stored it as 1-based (1,2,3,...). The UI should always show sets starting at 1.
    ///
    /// We detect the base per-exercise by looking at the minimum order in that exercise.
    private func displaySetNumber(for set: WorkoutSetLog, in ex: WorkoutSessionExercise) -> Int {
        let minOrder = ex.orderedSetLogs.map(\.order).min() ?? 0
        return (minOrder == 0) ? (set.order + 1) : set.order
    }

    @State private var showFinishConfirm = false
    @State private var showAbandonConfirm = false
    @State private var showRestTimer = false
    @State private var restSecondsToStart = 90
    @State private var activeExerciseID: UUID? = nil
    @State private var activeSetID: UUID? = nil
    @State private var targetAppliedBanner: TargetAppliedBanner? = nil
    
    @State private var coachPrompt: CoachPromptContext? = nil
    @State private var nextTargets: [UUID: PinnedTarget] = [:]
    
    @State private var prToast: PRToast? = nil
    @State private var prBadgesBySetId: [UUID: [CoachSuggestionService.PRAchievement]] = [:]
    @State private var confettiToken: UUID? = nil
    @State private var celebratedPRSetIDs: Set<UUID> = []
    
    @State private var prDetails: PRDetailsContext? = nil
    
    @State private var showReflectionSheet = false
    @State private var dismissAfterReflectionSheet = false
    
    private struct PRDetailsContext: Identifiable, Hashable {
        // Use setId as identity so it behaves nicely
        var id: UUID { setId }

        let setId: UUID
        let exerciseName: String
        let setNumber: Int
        let achievements: [CoachSuggestionService.PRAchievement]

        let weight: Double?
        let reps: Int?
        let unit: String
    }

    private struct PRToast: Identifiable, Equatable {
        let id = UUID()
        let title: String
        let subtitle: String
    }

    private let coachService = CoachSuggestionService()
    private let prService = PersonalRecordsService()

    private let continueNav = WorkoutContinueNavigator()

    private var isReadOnly: Bool { session.status != .inProgress }
    private var isInProgress: Bool { session.status == .inProgress }

    var body: some View {
        ZStack {
            ScrollViewReader { proxy in
                List {
                    headerSection
                    summarySectionIfReadOnly
                    exercisesSection(proxy: proxy)
                }
                .accessibilityIdentifier("WorkoutSession.Screen")
                .navigationTitle(session.sourceRoutineNameSnapshot ?? "Workout")
                .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(.visible, for: .navigationBar)
        .toolbarBackground(.ultraThinMaterial, for: .navigationBar)
                .safeAreaInset(edge: .bottom) { bottomInset(proxy: proxy) }
                .safeAreaInset(edge: .top) {
                    if let banner = targetAppliedBanner {
                        TargetAppliedBannerView(text: banner.text) {
                            withAnimation(.snappy) { targetAppliedBanner = nil }
                        }
                        .padding(.horizontal, 12)
                        .padding(.top, 6)
                        .transition(.move(edge: .top).combined(with: .opacity))
                    }
                }
                .toolbar { toolbarContent }
                .confirmationDialog(
                    "Finish workout?",
                    isPresented: $showFinishConfirm,
                    titleVisibility: .visible
                ) {
                    Button("Finish & Save", role: .destructive) { finish() }
                    Button("Keep Logging", role: .cancel) { }
                } message: {
                    Text("This will mark the session as completed.")
                }
                .confirmationDialog(
                    "Abandon session?",
                    isPresented: $showAbandonConfirm,
                    titleVisibility: .visible
                ) {
                    Button("Abandon", role: .destructive) { abandon() }
                    Button("Cancel", role: .cancel) { }
                } message: {
                    Text("This will mark the session as abandoned (not completed).")
                }
                .task(id: session.id) {
                    await applyGoalPrefillIfNeeded()
                    await reloadPinnedTargets()
                }
                .safeAreaInset(edge: .top) {
                    if let prToast {
                        PRToastView(
                            title: prToast.title,
                            subtitle: prToast.subtitle,
                            onDismiss: { withAnimation(.snappy) { self.prToast = nil } }
                        )
                        .padding(.horizontal, 12)
                        .padding(.top, 6)
                        .transition(.move(edge: .top).combined(with: .opacity))
                    }
                }
            }
            if let token = confettiToken {
                ConfettiBurstView(token: token)
                    .ignoresSafeArea()
                    .transition(.opacity)
            }
        }
        .sheet(isPresented: $showReflectionSheet, onDismiss: {
            if dismissAfterReflectionSheet { dismiss() }
            dismissAfterReflectionSheet = false
        }) {
            SessionReflectionSheet(session: session)
        }
        .sheet(item: $prDetails) { ctx in
            PRDetailsSheetView(ctx: ctx)
        }
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("WorkoutSession.Screen")
    }

    private func sessionList(proxy: ScrollViewProxy) -> some View {
        List {
            headerSection
            summarySectionIfReadOnly
            exercisesSection(proxy: proxy)
        }
        .accessibilityIdentifier("WorkoutSession.Screen.List")
        .navigationTitle(session.sourceRoutineNameSnapshot ?? "Workout")
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(.visible, for: .navigationBar)
        .toolbarBackground(.ultraThinMaterial, for: .navigationBar)
        .safeAreaInset(edge: .top) { topInset }
        .safeAreaInset(edge: .bottom) { bottomInset(proxy: proxy) }
        .toolbar { toolbarContent }
        .confirmationDialog(
            "Finish workout?",
            isPresented: $showFinishConfirm,
            titleVisibility: .visible
        ) {
            Button("Finish & Save", role: .destructive) { finish() }
            Button("Keep Logging", role: .cancel) { }
        } message: {
            Text("This will mark the session as completed.")
        }
        .confirmationDialog(
            "Abandon session?",
            isPresented: $showAbandonConfirm,
            titleVisibility: .visible
        ) {
            Button("Abandon", role: .destructive) { abandon() }
            Button("Cancel", role: .cancel) { }
        } message: {
            Text("This will mark the session as abandoned (not completed).")
        }
        .task(id: session.id) {
            await applyGoalPrefillIfNeeded()
            await reloadPinnedTargets()
        }
    }

    @ViewBuilder
    private var topInset: some View {
        VStack(spacing: 8) {
            if let prToast {
                PRToastView(
                    title: prToast.title,
                    subtitle: prToast.subtitle,
                    onDismiss: { withAnimation(.snappy) { self.prToast = nil } }
                )
                .transition(.move(edge: .top).combined(with: .opacity))
            }

            if let banner = targetAppliedBanner {
                TargetAppliedBannerView(text: banner.text) {
                    withAnimation(.snappy) { targetAppliedBanner = nil }
                }
                .transition(.move(edge: .top).combined(with: .opacity))
            }
        }
        .padding(.horizontal, 12)
        .padding(.top, 6)
    }

    // MARK: Sections

    private var headerSection: some View {
        Section {
            HStack {
                LabeledContent("Started") {
                    Text(session.startedAt, format: .dateTime.hour().minute())
                }
                Spacer()
                LabeledContent("Status") {
                    Text(statusLabel)
                        .foregroundStyle(session.status == .inProgress ? .secondary : .primary)
                }
            }

            HStack {
                LabeledContent("Elapsed") {
                    Text(timeString(session.elapsedSeconds()))
                        .monospacedDigit()
                }
                Spacer()
                if session.isPaused {
                    Text("Paused").font(.caption).foregroundStyle(.secondary)
                }
            }

            let completedSets = allSets.filter(\.completed).count
            let totalSets = allSets.count

            ProgressView(value: totalSets == 0 ? 0 : Double(completedSets) / Double(totalSets)) {
                Text("Progress")
            } currentValueLabel: {
                Text("\(completedSets)/\(max(totalSets, 1)) sets")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var summarySectionIfReadOnly: some View {
        Group {
            if isReadOnly {
                Section("Summary") {
                    let completedSets = allSets.filter(\.completed).count
                    let totalSets = allSets.count

                    let volume = allSets.reduce(0.0) { acc, set in
                        guard set.completed else { return acc }
                        let reps = Double(set.reps ?? 0)
                        let w = set.weight ?? 0
                        return acc + (reps * w)
                    }

                    LabeledContent("Sets") { Text("\(completedSets)/\(totalSets)") }

                    LabeledContent("Volume") {
                        Text(String(format: "%.0f", volume))
                            .foregroundStyle(.secondary)
                    }

                    if let endedAt = session.endedAt {
                        LabeledContent("Ended") {
                            Text(endedAt, format: .dateTime.hour().minute())
                        }
                    }
                }

                Section("Reflection") {
                    if let mood = session.reflectionMood {
                        LabeledContent("Mood") {
                            Text(mood.displayText)
                        }
                    }

                    let note = (session.reflectionNote ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                    if !note.isEmpty {
                        Text(note)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }

                    Button(hasReflection ? "Edit Reflection" : "Add Reflection") {
                        dismissAfterReflectionSheet = false
                        showReflectionSheet = true
                    }
                    .fontWeight(.semibold)
                }
            }
        }
    }

    // MARK: Data helpers

    private var sortedExercises: [WorkoutSessionExercise] {
        session.exercises.sorted { $0.order < $1.order }
    }

    private var allSets: [WorkoutSetLog] {
        sortedExercises.flatMap { sortedSets(for: $0) }
    }

    private func sortedSets(for ex: WorkoutSessionExercise) -> [WorkoutSetLog] {
        ex.setLogs.sorted { $0.order < $1.order }
    }

    private var statusLabel: String {
        switch session.status {
        case .inProgress: return "In progress"
        case .completed: return "Completed"
        case .abandoned: return "Abandoned"
        }
    }
    
    private var hasReflection: Bool {
        if session.reflectionMood != nil { return true }
        let note = (session.reflectionNote ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        return !note.isEmpty
    }

    // MARK: Logging actions

    private func continueLogging(proxy: ScrollViewProxy) {
        if session.isPaused {
            session.resume()
            withAnimation { showRestTimer = false }
            saveOrAssert("resume")
        }

        let exercises = sortedExercises
        guard !exercises.isEmpty else { return }

        guard let targetID = continueNav.nextTargetSetID(
            exercises: exercises,
            activeExerciseID: activeExerciseID,
            activeSetID: activeSetID
        ) else { return }

        // Update cursor so repeated Continue advances predictably.
        if let owningExercise = exercises.first(where: { ex in
            ex.setLogs.contains(where: { $0.id == targetID })
        }) {
            activeExerciseID = owningExercise.id
        }
        activeSetID = targetID

        scrollToSet(targetID, proxy: proxy)
    }

    private func handleSetCompleted(
        ex: WorkoutSessionExercise,
        set: WorkoutSetLog,
        suggestedRest: Int?
    ) {
        guard isInProgress, !session.isPaused else { return }

        let prompt = coachService.makePrompt(
            completedWeight: set.weight,
            completedReps: set.reps,
            weightUnitRaw: set.weightUnit.rawValue,
            rpe: set.rpe,
            plannedRestSeconds: set.targetRestSeconds,
            defaultRestSeconds: suggestedRest ?? 90
        )

        coachPrompt = CoachPromptContext(
            sessionExerciseModelId: ex.id,
            exerciseId: ex.exerciseId,
            completedSetId: set.id,
            completedSetOrder: set.order,
            prompt: prompt
        )

        // Start rest timer using coach suggestion
        restSecondsToStart = max(1, prompt.suggestedRestSeconds)
        restTimerRunID = UUID()
        withAnimation { showRestTimer = true }
    }

    // MARK: View builders

    @ViewBuilder
    private func exercisesSection(proxy: ScrollViewProxy) -> some View {
        if sortedExercises.isEmpty {
            emptyExercisesSection
        } else {
            ForEach(sortedExercises, id: \.id) { ex in
                exerciseSection(ex, proxy: proxy)
            }
        }
    }

    private var emptyExercisesSection: some View {
        Section {
            ContentUnavailableView(
                "No exercises yet",
                systemImage: "dumbbell",
                description: Text("Create routines later. For now you can Quick Start and finish the session.")
            )
        }
    }

    private func exerciseSection(_ ex: WorkoutSessionExercise, proxy: ScrollViewProxy) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            exerciseCardHeader(ex)

            VStack(alignment: .leading, spacing: 10) {
                setsList(for: ex, proxy: proxy)
            }
        }
        .padding(14)
        .background(exerciseCardBackground)
        .listRowInsets(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
        .listRowSeparator(.hidden)
        .listRowBackground(Color.clear)
    }

    private func exerciseCardHeader(_ ex: WorkoutSessionExercise) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(ex.exerciseNameSnapshot)
                .font(.headline)
                .foregroundStyle(.primary)
                .frame(maxWidth: .infinity, alignment: .leading)

            if isInProgress, let t = nextTargets[ex.exerciseId] {
                HStack(spacing: 8) {
                    Text("Next: \(t.text)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(2)

                    Spacer(minLength: 8)

                    Button("Apply") {
                        applyPinnedTarget(for: ex)
                    }
                    .font(.caption.weight(.semibold))
                    .buttonStyle(.bordered)
                }
            }
        }
    }

    private var exerciseCardBackground: some View {
        RoundedRectangle(cornerRadius: 18, style: .continuous)
            .fill(Color.secondary.opacity(0.05))
            .overlay(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .stroke(Color.secondary.opacity(0.12), lineWidth: 1)
            )
    }

    @ViewBuilder
    private func setsList(for ex: WorkoutSessionExercise, proxy: ScrollViewProxy) -> some View {
        let sets = sortedSets(for: ex)

        VStack(spacing: 10) {
            ForEach(sets, id: \.id) { set in
                let state = setRowVisualState(for: set)

                setRow(ex: ex, set: set, proxy: proxy)
                    .id(set.id)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 10)
                    .background(setRowChrome(state: state))
                    .contentShape(Rectangle())
                    .simultaneousGesture(
                        TapGesture().onEnded {
                            markActive(exerciseID: ex.id, setID: set.id)
                        }
                    )
            }
        }
    }

    // MARK: - Row styling

    private enum SetRowVisualState {
        case pending
        case current
        case done
        case behind
    }

    private func setRowVisualState(for set: WorkoutSetLog) -> SetRowVisualState {
        if activeSetID == set.id { return .current }
        if set.completed { return .done }
        if isBehind(set) { return .behind }
        return .pending
    }

    private var behindSetIDs: Set<UUID> {
        guard isInProgress, let activeSetID else { return [] }

        let ordered: [WorkoutSetLog] = sortedExercises.flatMap { ex in
            sortedSets(for: ex)
        }

        guard let activeIndex = ordered.firstIndex(where: { $0.id == activeSetID }) else { return [] }

        return Set(
            ordered.prefix(activeIndex)
                .filter { !$0.completed }
                .map(\.id)
        )
    }

    private func isBehind(_ set: WorkoutSetLog) -> Bool {
        behindSetIDs.contains(set.id)
    }

    private func setRowChrome(state: SetRowVisualState) -> some View {
        let bg: Color
        let border: Color
        let bar: Color?

        switch state {
        case .pending:
            bg = Color.secondary.opacity(0.03)
            border = Color.secondary.opacity(0.10)
            bar = nil
        case .current:
            bg = Color.accentColor.opacity(0.12)
            border = Color.accentColor.opacity(0.28)
            bar = Color.accentColor
        case .done:
            bg = Color.green.opacity(0.12)
            border = Color.green.opacity(0.22)
            bar = nil
        case .behind:
            bg = Color.orange.opacity(0.06)
            border = Color.orange.opacity(0.18)
            bar = nil
        }

        return RoundedRectangle(cornerRadius: 14, style: .continuous)
            .fill(bg)
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(border, lineWidth: 1)
            )
            .overlay(alignment: .leading) {
                if let bar {
                    Capsule()
                        .fill(bar)
                        .frame(width: 4)
                        .padding(.leading, 10)
                        .padding(.vertical, 10)
                }
            }
    }



    @ViewBuilder
    private func bottomInset(proxy: ScrollViewProxy) -> some View {
        VStack(spacing: 10) {
            if showRestTimer && isInProgress && !session.isPaused {
                if let ctx = coachPrompt, isInProgress && !session.isPaused {
                    CoachPromptCardView(
                        title: ctx.prompt.title,
                        message: ctx.prompt.message,
                        suggestedRestSeconds: ctx.prompt.suggestedRestSeconds,
                        weightActionTitle: ctx.prompt.weightLabel.map { "\($0) next set" },
                        repsActionTitle: ctx.prompt.repsLabel.map { "\($0) next set" },
                        onApplyWeight: ctx.prompt.weightDelta == nil ? nil : { applyCoachWeight(ctx, proxy: proxy) },
                        onApplyReps: ctx.prompt.repsDelta == nil ? nil : { applyCoachReps(ctx, proxy: proxy) },
                        onStartRest: {
                            restSecondsToStart = max(1, ctx.prompt.suggestedRestSeconds)
                            restTimerRunID = UUID()
                            withAnimation { showRestTimer = true }
                        },
                        onDismiss: { withAnimation { coachPrompt = nil } }
                    )
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                }

                RestTimerView(
                    initialSeconds: restSecondsToStart,
                    autostart: prefs.autoStartRest
                ) {
                    withAnimation { showRestTimer = false }
                }
                .id(restTimerRunID)
                .transition(.move(edge: .bottom).combined(with: .opacity))
            }

            if let toast = logging.undoToast, isInProgress {
                UndoToastView(
                    message: toast.message,
                    onUndo: { logging.undoLast(context: modelContext) },
                    onDismiss: { logging.clearUndoToast() }
                )
                .transition(.move(edge: .bottom).combined(with: .opacity))
            }

            if isInProgress {
                HStack(spacing: 10) {
                    Button {
                        continueLogging(proxy: proxy)
                    } label: {
                        Label(session.isPaused ? "Resume" : "Continue",
                              systemImage: session.isPaused ? "play.fill" : "arrow.down.to.line")
                    }
                    .accessibilityIdentifier("WorkoutSession.ContinueButton")
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)

                    if !session.isPaused {
                        Button {
                            session.pause()
                            withAnimation { showRestTimer = false }
                            saveOrAssert("pause")
                        } label: {
                            Image(systemName: "pause.fill")
                        }
                        .buttonStyle(.bordered)
                        .controlSize(.large)
                        .accessibilityLabel("Pause")
                    }

                    Button {
                        showFinishConfirm = true
                    } label: {
                        Label("Finish", systemImage: "checkmark.circle")
                    }
                    .accessibilityIdentifier("WorkoutSession.FinishButton")
                    .buttonStyle(.bordered)
                    .controlSize(.large)
                }
                .padding(.top, 2)
            }
        }
        .padding(.horizontal, 12)
        .padding(.bottom, 10)
        .background(.ultraThinMaterial)
    }

    @ToolbarContentBuilder
    private var toolbarContent: some ToolbarContent {
        ToolbarItem(placement: .topBarLeading) {
            if isInProgress {
                Button {
                    if showRestTimer {
                        withAnimation { showRestTimer = false }
                    } else {
                        restSecondsToStart = max(1, prefs.defaultRestSeconds)
                        restTimerRunID = UUID()
                        withAnimation { showRestTimer = true }
                    }
                } label: {
                    Label(
                        showRestTimer ? "Hide Rest" : "Rest",
                        systemImage: showRestTimer ? "timer.circle.fill" : "timer.circle"
                    )
                }
                .accessibilityIdentifier("WorkoutSession.RestTimerButton")
            }
        }

        ToolbarItem(placement: .topBarTrailing) {
            if isInProgress {
                Menu {
                    Button("Abandon", systemImage: "xmark.circle", role: .destructive) {
                        showAbandonConfirm = true
                    }
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
            } else {
                Button("Close") { dismiss() }
                    .fontWeight(.semibold)
            }
        }
    }

    // MARK: Finish/abandon

    private func finish() {
        if session.isPaused { session.resume() }
        session.endedAt = Date()
        session.status = .completed
        saveOrAssert("finish")

        // Optional, post-session, never blocks logging flow:
        // we only prompt if the user hasn't added a reflection yet.
        if !hasReflection {
            dismissAfterReflectionSheet = true
            showReflectionSheet = true
        } else {
            dismiss()
        }
    }

    private func abandon() {
        if session.isPaused { session.resume() }
        session.endedAt = Date()
        session.status = .abandoned
        saveOrAssert("abandon")
        dismiss()
    }

    // MARK: Persistence + formatting

    private func saveOrAssert(_ label: String) {
        do { try modelContext.save() }
        catch { assertionFailure("Failed to save (\(label)): \(error)") }
    }

    private func timeString(_ s: Int) -> String {
        let m = s / 60
        let r = s % 60
        return String(format: "%d:%02d", m, r)
    }
    
    private func markActive(exerciseID: UUID, setID: UUID?) {
        activeExerciseID = exerciseID
        activeSetID = setID
    }
    
    @ViewBuilder
    private func setRow(ex: WorkoutSessionExercise, set: WorkoutSetLog, proxy: ScrollViewProxy) -> some View {
        if isTimedSet(set) {
            TimedSetEditorRow(
                set: set,
                setNumber: displaySetNumber(for: set, in: ex),
                isReadOnly: isReadOnly,
                showsDistance: (ex.trackingStyle.showsDistance || set.targetDistance != nil || set.actualDistance != nil),
                onPersist: {
                    markActive(exerciseID: ex.id, setID: set.id)
                    saveOrAssert("set edit")
                },
                onToggleComplete: {
                    markActive(exerciseID: ex.id, setID: set.id)
                    logging.toggleCompleted(set, context: modelContext)
                    saveOrAssert("toggle complete")
                },
                onCopySet: {
                    markActive(exerciseID: ex.id, setID: set.id)
                    if !isReadOnly, let newSet = logging.copySet(set, in: ex, context: modelContext) {
                        applyTimedTemplate(from: set, to: newSet, prefillActuals: true)
                        markActive(exerciseID: ex.id, setID: newSet.id)
                        saveOrAssert("copy set")
                        scrollToSet(newSet.id, proxy: proxy)
                    }
                    saveOrAssert("copy set")
                },
                onAddSet: {
                    markActive(exerciseID: ex.id, setID: set.id)
                    if !isReadOnly, let newSet = logging.addSet(to: ex, after: set, template: set, context: modelContext) {
                        // "Add" should keep targets but not clone actual duration/distance.
                        applyTimedTemplate(from: set, to: newSet, prefillActuals: false)
                        newSet.actualDurationSeconds = nil
                        newSet.actualDistance = nil
                        newSet.completed = false
                        newSet.completedAt = nil

                        markActive(exerciseID: ex.id, setID: newSet.id)
                        saveOrAssert("add set")
                        scrollToSet(newSet.id, proxy: proxy)
                    }
                },
                onDeleteSet: {
                    markActive(exerciseID: ex.id, setID: set.id)
                    if !isReadOnly {
                        logging.deleteSet(set, from: ex, context: modelContext)
                        saveOrAssert("delete set")
                        if activeSetID == set.id { activeSetID = nil }
                    }
                }
            )
        } else {
            WorkoutSetEditorRow(
                set: set,
                setNumber: displaySetNumber(for: set, in: ex),
                isReadOnly: isReadOnly,
                onCompleted: { suggestedRest in
                    handleSetCompleted(ex: ex, set: set, suggestedRest: suggestedRest)
                },
                onPersist: {
                    markActive(exerciseID: ex.id, setID: set.id)
                    saveOrAssert("set edit")
                },
                onToggleComplete: {
                    markActive(exerciseID: ex.id, setID: set.id)

                    let wasCompleted = set.completed
                    logging.toggleCompleted(set, context: modelContext)

                    // If user un-completes, clear PR markers so re-completing can celebrate again.
                    if wasCompleted && !set.completed {
                        prBadgesBySetId[set.id] = nil
                        celebratedPRSetIDs.remove(set.id)
                        return
                    }

                    // Only trigger celebration on the transition to completed.
                    if !wasCompleted && set.completed {
                        Task { await celebratePRIfNeeded(ex: ex, set: set) }
                    }
                },
                onCopySet: {
                    markActive(exerciseID: ex.id, setID: set.id)
                    if !isReadOnly, let newSet = logging.copySet(set, in: ex, context: modelContext) {
                        markActive(exerciseID: ex.id, setID: newSet.id)
                        scrollToSet(newSet.id, proxy: proxy)
                    }
                    saveOrAssert("copy set")
                },
                onAddSet: {
                    markActive(exerciseID: ex.id, setID: set.id)
                    if !isReadOnly, let newSet = logging.addSet(to: ex, after: set, template: set, context: modelContext) {
                        // "Add" keeps targets (plan) but clears actuals; otherwise it's indistinguishable from "Copy".
                        newSet.reps = nil
                        newSet.weight = nil
                        newSet.completed = false
                        newSet.completedAt = nil

                        markActive(exerciseID: ex.id, setID: newSet.id)
                        saveOrAssert("add set")
                        scrollToSet(newSet.id, proxy: proxy)
                    }
                },
                onDeleteSet: {
                    markActive(exerciseID: ex.id, setID: set.id)
                    if !isReadOnly {
                        logging.deleteSet(set, from: ex, context: modelContext)
                        saveOrAssert("delete set")
                        if activeSetID == set.id { activeSetID = nil }
                    }
                },
                onBumpReps: { delta in
                    markActive(exerciseID: ex.id, setID: set.id)
                    if !isReadOnly { logging.bumpReps(set, delta: delta, context: modelContext) }
                },
                onBumpWeight: { delta in
                    markActive(exerciseID: ex.id, setID: set.id)
                    if !isReadOnly { logging.bumpWeight(set, delta: delta, context: modelContext) }
                },
                weightStep: 2.5
            )
            .overlay(alignment: .topTrailing) {
                if let ach = prBadgesBySetId[set.id], !ach.isEmpty {
                    Button {
                        prDetails = PRDetailsContext(
                            setId: set.id,
                            exerciseName: ex.exerciseNameSnapshot,
                            setNumber: displaySetNumber(for: set, in: ex),
                            achievements: ach,
                            weight: set.weight,
                            reps: set.reps,
                            unit: set.weightUnit.rawValue
                        )
                    } label: {
                        Text("PR")
                            .font(.caption2.weight(.bold))
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(.thinMaterial, in: Capsule())
                            .overlay(Capsule().stroke(.yellow.opacity(0.35), lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                    .padding(.top, 6)
                    .accessibilityLabel("Show PR details")
                }
            }
        }
    }

    /// Timed / distance sets are detected by the presence of those target/actual fields.
    private func isTimedSet(_ set: WorkoutSetLog) -> Bool {
        set.targetDurationSeconds != nil ||
        set.actualDurationSeconds != nil ||
        set.targetDistance != nil ||
        set.actualDistance != nil
    }

    /// Keep cardio/mobility sets “timed” even when created via generic add/copy helpers that
    /// might only clone reps/weight fields.
    private func applyTimedTemplate(from template: WorkoutSetLog?, to set: WorkoutSetLog, prefillActuals: Bool) {
        guard let template else { return }
        guard isTimedSet(template) else { return }

        set.targetDurationSeconds = template.targetDurationSeconds
        set.targetDistance = template.targetDistance

        if prefillActuals {
            set.actualDurationSeconds = template.actualDurationSeconds ?? template.targetDurationSeconds
            set.actualDistance = template.actualDistance ?? template.targetDistance
        } else {
            // Keep whatever actuals it already had.
        }
    }

    @MainActor
    private func applyGoalPrefillIfNeeded() async {
        guard session.status == .inProgress else { return }
        guard let exId = goalPrefill.pendingExerciseId else { return }
        guard let target = goalPrefill.consumeIfMatches(exerciseId: exId) else { return }

        guard let ex = session.exercises.first(where: { $0.exerciseId == exId }) else { return }
        guard let set = ex.setLogs
            .sorted(by: { $0.order < $1.order })
            .first(where: { !$0.completed }) else { return }

        var changed = false

        // Only prefill if user hasn't already typed something
        if let w = target.weight, (set.weight ?? 0) == 0 {
            set.weight = w
            changed = true
        }
        if let r = target.reps, (set.reps ?? 0) == 0 {
            set.reps = r
            changed = true
        }

        if changed { try? modelContext.save() }

        // ✅ Banner feedback (always, so user knows what happened)
        let msg = changed
            ? bannerMessageApplied(target: target, setNumber: displaySetNumber(for: set, in: ex), unit: set.weightUnit.rawValue)
            : "Target already filled — nothing changed."

        showTargetAppliedBanner(msg)
    }
    
    private struct TargetAppliedBanner: Identifiable, Equatable {
        let id = UUID()
        let text: String
    }

    @MainActor
    private func showTargetAppliedBanner(_ text: String) {
        let banner = TargetAppliedBanner(text: text)
        withAnimation(.snappy) { targetAppliedBanner = banner }

        Task { [id = banner.id] in
            try? await Task.sleep(nanoseconds: 2_200_000_000) // ~2.2s
            await MainActor.run {
                guard targetAppliedBanner?.id == id else { return }
                withAnimation(.snappy) { targetAppliedBanner = nil }
            }
        }
    }

    private func bannerMessageApplied(target: GoalPrefillStore.Prefill, setNumber: Int, unit: String) -> String {
        var parts: [String] = []
        if let w = target.weight { parts.append("\(formatWeight(w)) \(unit)") }
        if let r = target.reps { parts.append("\(r) reps") }

        if parts.isEmpty {
            return "Target applied to Set \(setNumber)."
        } else {
            return "Target applied to Set \(setNumber): " + parts.joined(separator: " • ")
        }
    }

    private func formatWeight(_ w: Double) -> String {
        if w.rounded() == w { return String(Int(w)) }
        return String(format: "%.1f", w)
    }

    private struct TargetAppliedBannerView: View {
        let text: String
        let onDismiss: () -> Void

        var body: some View {
            HStack(spacing: 10) {
                Image(systemName: "checkmark.circle.fill")
                    .foregroundStyle(.green)

                Text(text)
                    .font(.subheadline)
                    .foregroundStyle(.primary)
                    .lineLimit(2)

                Spacer()

                Button(action: onDismiss) {
                    Image(systemName: "xmark")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14))
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .stroke(.secondary.opacity(0.15), lineWidth: 1)
            )
            .onTapGesture { onDismiss() }
        }
    }

    @MainActor
    private func fetchFirstIncompleteSetLog(sessionExerciseId: UUID) -> WorkoutSetLog? {
        let sid: UUID? = sessionExerciseId

        var fd = FetchDescriptor<WorkoutSetLog>(
            predicate: #Predicate<WorkoutSetLog> { s in
                s.completed == false &&
                s.sessionExercise?.id == sid
            },
            sortBy: [SortDescriptor(\WorkoutSetLog.order, order: .forward)]
        )
        fd.fetchLimit = 1
        return try? modelContext.fetch(fd).first
    }
    
    private func dismissKeyboard() {
    #if canImport(UIKit)
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder),
                                        to: nil, from: nil, for: nil)
    #endif
    }
    
    private func scrollToSet(_ id: UUID, proxy: ScrollViewProxy) {
        dismissKeyboard()
        DispatchQueue.main.async {
            withAnimation(.snappy) { proxy.scrollTo(id, anchor: .center) }
        }
    }
    
    private struct PinnedTarget: Hashable {
        let text: String
        let weight: Double?
        let reps: Int?
    }

    private struct CoachPromptContext: Identifiable, Hashable {
        let id = UUID()
        let sessionExerciseModelId: UUID   // WorkoutSessionExercise.id
        let exerciseId: UUID              // WorkoutSessionExercise.exerciseId
        let completedSetId: UUID
        let completedSetOrder: Int
        let prompt: CoachSuggestionService.Prompt
    }
    
    @MainActor
    private func reloadPinnedTargets() async {
        var out: [UUID: PinnedTarget] = [:]

        for ex in sortedExercises {
            do {
                let rec = try prService.records(for: ex.exerciseId, context: modelContext)
                if let t = try prService.nextTarget(for: ex.exerciseId, records: rec, context: modelContext) {
                    out[ex.exerciseId] = PinnedTarget(text: t.text, weight: t.targetWeight, reps: t.targetReps)
                }
            } catch {
                // ignore; keep UX smooth
            }
        }

        nextTargets = out
    }
    @MainActor
    private func applyPinnedTarget(for ex: WorkoutSessionExercise) {
        guard let t = nextTargets[ex.exerciseId] else { return }

        // Apply into the first incomplete set (by order); create one if none exist.
        let sets = sortedSets(for: ex)
        let targetSet: WorkoutSetLog

        if let s = sets.first(where: { !$0.completed }) {
            targetSet = s
        } else {
            // No available set: create a new one using your logging service
            if let newSet = logging.addSet(to: ex, template: sets.last, context: modelContext) {
                targetSet = newSet
            } else {
                return
            }
        }

        // Don't overwrite user-entered values
        if let w = t.weight, (targetSet.weight ?? 0) == 0 { targetSet.weight = w }
        if let r = t.reps, (targetSet.reps ?? 0) == 0 { targetSet.reps = r }

        saveOrAssert("apply next target")
    }
    
    @MainActor
    private func applyCoachWeight(_ ctx: CoachPromptContext, proxy: ScrollViewProxy) {
        guard let delta = ctx.prompt.weightDelta else { return }
        guard let ex = session.exercises.first(where: { $0.id == ctx.sessionExerciseModelId }) else { return }
        guard let completed = sortedSets(for: ex).first(where: { $0.id == ctx.completedSetId }) else { return }

        let next = nextEditableSet(after: completed, in: ex)
        guard let next else { return }

        let base = (next.weight ?? 0) > 0 ? (next.weight ?? 0) : (completed.weight ?? 0)
        next.weight = base + delta

        saveOrAssert("coach apply weight")
        coachPrompt = nil
        scrollToSet(next.id, proxy: proxy)
    }

    @MainActor
    private func applyCoachReps(_ ctx: CoachPromptContext, proxy: ScrollViewProxy) {
        guard let delta = ctx.prompt.repsDelta else { return }
        guard let ex = session.exercises.first(where: { $0.id == ctx.sessionExerciseModelId }) else { return }
        guard let completed = sortedSets(for: ex).first(where: { $0.id == ctx.completedSetId }) else { return }

        let next = nextEditableSet(after: completed, in: ex)
        guard let next else { return }

        let base = (next.reps ?? 0) > 0 ? (next.reps ?? 0) : (completed.reps ?? 0)
        next.reps = base + delta

        saveOrAssert("coach apply reps")
        coachPrompt = nil
        scrollToSet(next.id, proxy: proxy)
    }

    @MainActor
    private func nextEditableSet(after completed: WorkoutSetLog, in ex: WorkoutSessionExercise) -> WorkoutSetLog? {
        let sets = sortedSets(for: ex)

        if let existing = sets.first(where: { !$0.completed && $0.order > completed.order }) {
            return existing
        }

        // No future set exists → create one after the completed set
        if let newSet = logging.addSet(to: ex, after: completed, template: completed, context: modelContext) {
            return newSet
        }

        return nil
    }
    
    @MainActor
    private func celebratePRIfNeeded(ex: WorkoutSessionExercise, set: WorkoutSetLog) async {
        // Only celebrate completed sets with a timestamp
        guard !celebratedPRSetIDs.contains(set.id) else { return }
        guard set.completed, set.completedAt != nil else { return }

        // Fetch *previous history* for this exercise (excluding this set)
        let previous = fetchCompletedSetsForExercise(exerciseId: ex.exerciseId)
            .filter { $0.id != set.id }

        let prev = previous.map {
            CoachSuggestionService.CompletedSet(
                weight: $0.weight,
                reps: $0.reps,
                weightUnitRaw: $0.weightUnit.rawValue,
                rpe: $0.rpe
            )
        }

        let cur = CoachSuggestionService.CompletedSet(
            weight: set.weight,
            reps: set.reps,
            weightUnitRaw: set.weightUnit.rawValue,
            rpe: set.rpe
        )

        let achievements = coachService.prAchievements(completed: cur, previous: prev)
        guard !achievements.isEmpty else { return }
        celebratedPRSetIDs.insert(set.id)
        Haptics.success()

        // 1) Mark badge for this set row
        prBadgesBySetId[set.id] = achievements

        // 2) Toast message
        let headline = "PR!"
        let subtitle = achievements
            .map { "\($0.kind.rawValue): \($0.valueText)" }
            .joined(separator: " • ")

        withAnimation(.snappy) {
            prToast = PRToast(title: headline, subtitle: subtitle)
            confettiToken = UUID()
        }

        // auto-dismiss toast + confetti
        Task {
            try? await Task.sleep(nanoseconds: 2_200_000_000)
            await MainActor.run {
                withAnimation(.snappy) {
                    prToast = nil
                    confettiToken = nil
                }
            }
        }
    }

    private struct PRDetailsSheetView: View {
        let ctx: PRDetailsContext
        @Environment(\.dismiss) private var dismiss

        var body: some View {
            NavigationStack {
                List {
                    Section {
                        VStack(alignment: .leading, spacing: 6) {
                            Text(ctx.exerciseName)
                                .font(.headline)

                            HStack(spacing: 10) {
                                Text("Set \(ctx.setNumber)")
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)

                                Spacer()

                                if let w = ctx.weight {
                                    Text("\(formatWeight(w)) \(ctx.unit)")
                                        .font(.subheadline.weight(.semibold))
                                }
                                if let r = ctx.reps {
                                    Text("\(r) reps")
                                        .font(.subheadline.weight(.semibold))
                                }
                            }
                        }
                        .padding(.vertical, 4)
                    }

                    Section("Personal Records") {
                        ForEach(Array(ctx.achievements.enumerated()), id: \.offset) { _, a in
                            HStack(spacing: 10) {
                                Image(systemName: "trophy.fill")
                                    .foregroundStyle(.yellow)

                                VStack(alignment: .leading, spacing: 2) {
                                    Text(a.kind.rawValue)
                                        .font(.subheadline.weight(.semibold))
                                    Text(a.valueText)
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }

                                Spacer()
                            }
                            .padding(.vertical, 2)
                        }
                    }
                }
                .navigationTitle("PR")
                .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(.visible, for: .navigationBar)
        .toolbarBackground(.ultraThinMaterial, for: .navigationBar)
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) {
                        Button("Done") { dismiss() }
                    }
                }
            }
        }

        private func formatWeight(_ w: Double) -> String {
            w.rounded() == w ? String(Int(w)) : String(format: "%.1f", w)
        }
    }

    @MainActor
    private func fetchCompletedSetsForExercise(exerciseId: UUID) -> [WorkoutSetLog] {
        let exId: UUID? = exerciseId

        do {
            let fd = FetchDescriptor<WorkoutSetLog>(
                predicate: #Predicate<WorkoutSetLog> { s in
                    s.completed == true &&
                    s.sessionExercise?.exerciseId == exId
                },
                sortBy: [SortDescriptor(\WorkoutSetLog.completedAt, order: .forward)]
            )
            return try modelContext.fetch(fd)
        } catch {
            return []
        }
    }
    

    private struct TimedSetEditorRow: View {
        @Bindable var set: WorkoutSetLog
        @AppStorage(UnitPreferences.Keys.distanceUnitRaw)
        private var preferredDistanceUnitRaw: String = DistanceUnit.km.rawValue
        @Environment(\.horizontalSizeClass) private var horizontalSizeClass

        var setNumber: Int
        var isReadOnly: Bool
        var showsDistance: Bool

        var onPersist: () -> Void
        var onToggleComplete: () -> Void
        var onCopySet: () -> Void
        var onAddSet: () -> Void
        var onDeleteSet: () -> Void

        private var preferredDistanceUnit: DistanceUnit {
            DistanceUnit(rawValue: preferredDistanceUnitRaw) ?? .km
        }

        private var isCompact: Bool { horizontalSizeClass == .compact }
        private var stacksMetricsVertically: Bool { isCompact && showsDistance }
        private var metricSpacing: CGFloat { isCompact ? 10 : 16 }
        private var durationFieldWidth: CGFloat { isCompact ? 50 : 54 }
        private var distanceFieldWidth: CGFloat { isCompact ? 58 : 64 }

        var body: some View {
            HStack(alignment: .top, spacing: isCompact ? 8 : 14) {
                Text("\(setNumber)")
                    .font(.headline)
                    .frame(width: 28, alignment: .leading)
                    .foregroundStyle(.secondary)
                    .layoutPriority(2)

                VStack(alignment: .leading, spacing: 10) {
                    metricsBlock

                    SetRowActionsBar(
                        isReadOnly: isReadOnly,
                        onAction: { action in
                            switch action {
                            case .copy:
                                onCopySet()
                            case .add:
                                onAddSet()
                            case .delete:
                                onDeleteSet()
                            }
                        },
                        idPrefix: "WorkoutSetEditorRow.\(set.id.uuidString).Actions"
                    )
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .layoutPriority(1)

                Button {
                    if !isReadOnly { onToggleComplete() }
                } label: {
                    Image(systemName: set.completed ? "checkmark.circle.fill" : "circle")
                        .font(.title3)
                        .foregroundStyle(set.completed ? .green : .secondary)
                }
                .buttonStyle(.plain)
                .frame(width: 36, alignment: .trailing)
                .layoutPriority(2)
                .accessibilityLabel(set.completed ? "Mark incomplete" : "Mark complete")
                .accessibilityIdentifier("WorkoutSetEditorRow.\(set.id.uuidString).DoneToggle")
                .disabled(isReadOnly)
            }
            .padding(.vertical, 10)
            .contentShape(Rectangle())
        }

        @ViewBuilder
        private var metricsBlock: some View {
            if stacksMetricsVertically {
                VStack(alignment: .leading, spacing: 10) {
                    durationField

                    if showsDistance {
                        distanceField
                    }
                }
            } else {
                HStack(alignment: .top, spacing: metricSpacing) {
                    durationField

                    if showsDistance {
                        distanceField
                    }
                }
            }
        }

        private var durationField: some View {
            VStack(alignment: .leading, spacing: 6) {
                Text("Time (min)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .fixedSize(horizontal: true, vertical: false)

                HStack(spacing: isCompact ? 6 : 8) {
                    stepButton(system: "minus.circle") { bumpDurationMinutes(-1) }

                    TextField("—", text: durationMinutesBinding)
                        .multilineTextAlignment(.center)
                        .keyboardType(.numberPad)
                        .frame(width: durationFieldWidth)
                        .textFieldStyle(.roundedBorder)
                        .disabled(isReadOnly)

                    stepButton(system: "plus.circle") { bumpDurationMinutes(+1) }
                }
            }
            .layoutPriority(1)
        }

        private var distanceField: some View {
            VStack(alignment: .leading, spacing: 6) {
                Text(isCompact ? "Dist (\(preferredDistanceUnit.symbol))" : "Distance (\(preferredDistanceUnit.symbol))")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .fixedSize(horizontal: true, vertical: false)

                HStack(spacing: isCompact ? 6 : 8) {
                    stepButton(system: "minus.circle") { bumpDistance(-preferredDistanceUnit.stepSize) }

                    TextField("—", text: distanceBinding)
                        .multilineTextAlignment(.center)
                        .keyboardType(.decimalPad)
                        .frame(width: distanceFieldWidth)
                        .textFieldStyle(.roundedBorder)
                        .disabled(isReadOnly)

                    stepButton(system: "plus.circle") { bumpDistance(+preferredDistanceUnit.stepSize) }
                }
            }
            .layoutPriority(1)
        }

        private func stepButton(system: String, action: @escaping () -> Void) -> some View {
            Button {
                if !isReadOnly {
                    action()
                    onPersist()
                }
            } label: {
                Image(systemName: system)
                    .font(.title3)
            }
            .buttonStyle(.plain)
            .foregroundStyle(.secondary)
            .disabled(isReadOnly)
        }

        private var durationMinutesBinding: Binding<String> {
            Binding(
                get: {
                    let seconds = set.actualDurationSeconds ?? set.targetDurationSeconds
                    guard let seconds else { return "" }
                    let minutes = max(0, Int(round(Double(seconds) / 60.0)))
                    return minutes == 0 ? "" : String(minutes)
                },
                set: { newValue in
                    guard !isReadOnly else { return }
                    let trimmed = newValue.trimmingCharacters(in: .whitespacesAndNewlines)
                    guard let m = Int(trimmed), m >= 0 else {
                        set.actualDurationSeconds = nil
                        onPersist()
                        return
                    }
                    set.actualDurationSeconds = m * 60
                    onPersist()
                }
            )
        }

        private var distanceBinding: Binding<String> {
            Binding(
                get: {
                    guard let v = set.editableDistance(in: preferredDistanceUnit) else { return "" }
                    let rounded = (v * 10).rounded() / 10
                    return rounded == 0 ? "" : String(format: "%.1f", rounded)
                },
                set: { newValue in
                    guard !isReadOnly else { return }
                    let trimmed = newValue.trimmingCharacters(in: .whitespacesAndNewlines)
                    let normalized = trimmed.replacingOccurrences(of: ",", with: ".")
                    guard let d = Double(normalized), d >= 0 else {
                        set.setActualDistance(nil, preferredUnit: preferredDistanceUnit)
                        onPersist()
                        return
                    }
                    set.setActualDistance(d == 0 ? nil : d, preferredUnit: preferredDistanceUnit)
                    onPersist()
                }
            )
        }

        private func bumpDurationMinutes(_ delta: Int) {
            let currentSeconds = set.actualDurationSeconds ?? set.targetDurationSeconds ?? 0
            let currentMinutes = max(0, Int(round(Double(currentSeconds) / 60.0)))
            let next = max(0, currentMinutes + delta)
            set.actualDurationSeconds = next * 60
        }

        private func bumpDistance(_ delta: Double) {
            let current = set.editableDistance(in: preferredDistanceUnit) ?? 0
            let next = max(0, current + delta)
            set.setActualDistance(next == 0 ? nil : next, preferredUnit: preferredDistanceUnit)
        }
    }

    private enum Haptics {
        static func success() {
    #if canImport(UIKit)
            let g = UINotificationFeedbackGenerator()
            g.prepare()
            g.notificationOccurred(.success)
    #endif
        }
    }
}
