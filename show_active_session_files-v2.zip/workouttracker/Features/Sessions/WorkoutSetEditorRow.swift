import SwiftUI
import UIKit

/// Fast inline editing for reps/weight + done toggle.
/// Aligned to `WorkoutSetLog` (completed/targetRestSeconds/weightUnit).
///
/// Changes for "tap-tap-done":
/// - plus/minus steppers for reps + weight (so you rarely open the keyboard)
/// - mini action bar: copy set, +1 set, delete
/// - clearer "done" state
struct WorkoutSetEditorRow: View {
    @Bindable var set: WorkoutSetLog
    
    @AppStorage(UnitPreferences.Keys.weightUnitRaw)
    private var preferredUnitRaw: String = WeightUnit.kg.rawValue

    @Environment(\.horizontalSizeClass) private var horizontalSizeClass

    private var preferredUnit: WeightUnit {
        WeightUnit(rawValue: preferredUnitRaw) ?? .kg
    }

    private var isCompact: Bool { horizontalSizeClass == .compact }
    private var repsFieldWidth: CGFloat { isCompact ? 54 : 62 }
    private var weightFieldWidth: CGFloat { isCompact ? 68 : 84 }

    let setNumber: Int
    let isReadOnly: Bool

    /// Called only when a set transitions from not-done -> done. Parameter is suggested rest seconds.
    var onCompleted: ((Int?) -> Void)? = nil

    /// Called when the user edits fields directly (TextFields). Keep this light (save context).
    var onPersist: (() -> Void)? = nil

    // Actions (typically backed by `WorkoutLoggingService` in the parent screen)
    var onToggleComplete: (() -> Void)? = nil
    var onCopySet: (() -> Void)? = nil
    var onAddSet: (() -> Void)? = nil
    var onDeleteSet: (() -> Void)? = nil
    var onBumpReps: ((Int) -> Void)? = nil
    var onBumpWeight: ((Double) -> Void)? = nil

    /// UI-only tuning: default weight step if you don't provide a custom one.
    var weightStep: Double = 2.5

    @State private var persistDebounceTask: Task<Void, Never>?

    /// Used to make accessibility identifiers unique per row.
    /// This keeps UI tests deterministic even when multiple sets are on screen.
    private var a11yPrefix: String { "WorkoutSetEditorRow.\(set.id.uuidString)" }

    private var repsBinding: Binding<String> {
        Binding<String>(
            get: { set.reps.map(String.init) ?? "" },
            set: { newValue in
                let trimmed = newValue.trimmingCharacters(in: .whitespacesAndNewlines)
                set.reps = Int(trimmed)
                schedulePersist()
            }
        )
    }
    
    private var weightBinding: Binding<String> {
        preferredWeightBinding(for: set)
    }

    private func preferredWeightBinding(for set: WorkoutSetLog) -> Binding<String> {
        Binding(
            get: {
                guard let w = set.weight(in: preferredUnit) else { return "" }
                return w.rounded() == w ? String(Int(w)) : String(format: "%.1f", w)
            },
            set: { txt in
                let t = txt.trimmingCharacters(in: .whitespacesAndNewlines)
                if t.isEmpty {
                    set.setWeight(nil, preferredUnit: preferredUnit)
                    schedulePersist()
                    return
                }

                let v = Double(t.replacingOccurrences(of: ",", with: ".")) ?? 0
                set.setWeight(v == 0 ? nil : v, preferredUnit: preferredUnit)
                schedulePersist()
            }
        )
    }

    private var targetHint: String? {
        var parts: [String] = []
        if let tr = set.targetReps { parts.append("\(tr) reps") }
        if let tw = set.targetWeight(in: preferredUnit) {
            parts.append("@ \(formatWeight(tw)) \(preferredUnit.label)")
        }
        if let r = set.targetRPE { parts.append("RPE \(formatRPE(r))") }
        guard !parts.isEmpty else { return nil }
        return "Target: " + parts.joined(separator: " ")
    }

    var body: some View {
        HStack(alignment: .center, spacing: 8) {
            // Fixed left index column so it never gets squeezed.
            Text("\(setNumber)")
                .font(.headline)
                .frame(width: 28, alignment: .leading)
                .foregroundStyle(set.completed ? .secondary : .primary)
                .layoutPriority(2)

            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: isCompact ? 8 : 12) {
                    valueEditor(
                        title: "Reps",
                        text: repsBinding,
                        keyboard: .numberPad,
                        width: repsFieldWidth,
                        minus: { bumpReps(-1) },
                        plus: { bumpReps(+1) },
                        idBase: "\(a11yPrefix).Reps"
                    )

                    valueEditor(
                        title: isCompact ? "Wt (\(preferredUnit.label))" : "Weight",
                        text: weightBinding,
                        keyboard: .decimalPad,
                        width: weightFieldWidth,
                        minus: { bumpWeight(-weightStep) },
                        plus: { bumpWeight(+weightStep) },
                        trailing: isCompact ? nil : AnyView(
                            Text(preferredUnit.label)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        ),
                        idBase: "\(a11yPrefix).Weight"
                    )
                }

                if let hint = targetHint {
                    Text(hint)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                        .minimumScaleFactor(0.85)
                }

                SetRowActionsBar(
                    isReadOnly: isReadOnly,
                    onAction: { action in
                        switch action {
                        case .copy:
                            onCopySet?()
                        case .add:
                            onAddSet?()
                        case .delete:
                            onDeleteSet?()
                        }
                    },
                    idPrefix: "\(a11yPrefix).Actions"
                )
            }
            .layoutPriority(1)

            Spacer(minLength: 0)

            Button {
                toggleDone()
            } label: {
                Image(systemName: set.completed ? "checkmark.circle.fill" : "circle")
                    .font(.title3)
                    .symbolRenderingMode(.hierarchical)
                    .foregroundStyle(set.completed ? .green : .secondary)
            }
            .buttonStyle(.plain)
            .frame(width: 44, alignment: .trailing)
            .layoutPriority(2)
            .disabled(isReadOnly)
            .accessibilityLabel(set.completed ? "Mark set not completed" : "Mark set completed")
            .accessibilityIdentifier("\(a11yPrefix).DoneToggle")
        }
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("\(a11yPrefix).Row")
        .padding(.vertical, 6)
        .onDisappear {
            // Don’t drop the last typed values if the row/screen disappears.
            persistDebounceTask?.cancel()
            persistDebounceTask = nil
            onPersist?() // flush immediately
        }
    }

    // MARK: - Actions

    private func toggleDone() {
        let wasCompleted = set.completed

        if let onToggleComplete {
            onToggleComplete()

            // Defer the completion check so SwiftUI/SwiftData have applied the mutation.
            DispatchQueue.main.async {
                if !wasCompleted && set.completed {
                    fireCompletionHaptic()
                    onCompleted?(set.targetRestSeconds)
                }
            }
            return
        }

        // Fallback path (no service)
        set.completed.toggle()
        set.completedAt = set.completed ? Date() : nil
        onPersist?()

        if !wasCompleted && set.completed {
            fireCompletionHaptic()
            onCompleted?(set.targetRestSeconds)
        }
    }


    private func bumpReps(_ delta: Int) {
        guard !isReadOnly else { return }
        if let onBumpReps {
            onBumpReps(delta)
        } else {
            let cur = set.reps ?? 0
            set.reps = max(0, cur + delta)
            onPersist?()
        }
    }

    private func bumpWeight(_ delta: Double) {
        guard !isReadOnly else { return }
        if let onBumpWeight {
            onBumpWeight(delta)
        } else {
            let curPreferred = set.weight(in: preferredUnit) ?? 0
            let nextPreferred = max(0, curPreferred + delta)
            set.setWeight(nextPreferred == 0 ? nil : nextPreferred, preferredUnit: preferredUnit)
            onPersist?()
        }
    }

    private func schedulePersist() {
        guard !isReadOnly else { return }
        guard let onPersist else { return }

        persistDebounceTask?.cancel()
        persistDebounceTask = Task {
            try? await Task.sleep(nanoseconds: 350_000_000) // ~0.35s debounce
            if Task.isCancelled { return }
            await MainActor.run { onPersist() }
        }
    }

    // MARK: - Subviews

    private func valueEditor(
        title: String,
        text: Binding<String>,
        keyboard: UIKeyboardType,
        width: CGFloat,
        minus: @escaping () -> Void,
        plus: @escaping () -> Void,
        trailing: AnyView? = nil,
        idBase: String
    ) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)

            HStack(spacing: 6) {
                StepIconButton(
                    systemName: "minus.circle",
                    action: minus,
                    accessibilityID: "\(idBase).Minus"
                )
                    .disabled(isReadOnly)

                TextField("—", text: text)
                    .multilineTextAlignment(.trailing)
                    .keyboardType(keyboard)
                    .frame(width: width)
                    .textFieldStyle(.roundedBorder)
                    .disabled(isReadOnly)
                    .accessibilityIdentifier("\(idBase).Field")

                StepIconButton(
                    systemName: "plus.circle",
                    action: plus,
                    accessibilityID: "\(idBase).Plus"
                )
                    .disabled(isReadOnly)

                if let trailing { trailing }
            }
        }
    }

    private struct StepIconButton: View {
        let systemName: String
        let action: () -> Void
        let accessibilityID: String

        var body: some View {
            Button(action: action) {
                Image(systemName: systemName)
                    .font(.title3)
                    .foregroundStyle(.secondary)
            }
            .buttonStyle(.plain)
            .accessibilityIdentifier(accessibilityID)
        }
    }

    // MARK: Formatting

    private func formatWeight(_ w: Double) -> String {
        if w.rounded() == w { return String(Int(w)) }
        return String(w)
    }

    private func formatRPE(_ r: Double) -> String {
        if r.rounded() == r { return String(Int(r)) }
        return String(r)
    }
    
    private func fireCompletionHaptic() {
    #if canImport(UIKit)
        let g = UIImpactFeedbackGenerator(style: .light)
        g.prepare()
        g.impactOccurred()
    #endif
    }
}
